function p = randi(n)
p = ceil(rand*n);
end