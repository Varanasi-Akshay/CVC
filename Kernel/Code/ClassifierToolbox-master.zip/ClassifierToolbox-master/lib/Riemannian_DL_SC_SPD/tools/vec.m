function v=vec(x)
v = x(:);
end