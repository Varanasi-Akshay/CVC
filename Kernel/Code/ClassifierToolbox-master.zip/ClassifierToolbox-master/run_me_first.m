% Add folders to path.

addpath(pwd);

cd lib/;
addpath(genpath(pwd));
cd ..;

cd auxiliary/;
addpath(genpath(pwd));
cd ..;

cd algorithm;
addpath(genpath(pwd));
cd ../;





