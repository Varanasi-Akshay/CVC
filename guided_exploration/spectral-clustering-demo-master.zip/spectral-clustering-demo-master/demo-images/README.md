# example images made via the associated spectral clustering code
